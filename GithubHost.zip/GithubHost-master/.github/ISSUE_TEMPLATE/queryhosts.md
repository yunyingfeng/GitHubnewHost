---
name: QueryHosts
about: 查询host
title: "[Host]YYYY-MM-dd"
labels: host-query
assignees: ''

---

+ 建议在查询之前看看是否已经存在日期靠近的host，直接使用即可
+ 建议标题为`[Host]YYYY-MM-dd`，比如`[Host]2021-01-01`
