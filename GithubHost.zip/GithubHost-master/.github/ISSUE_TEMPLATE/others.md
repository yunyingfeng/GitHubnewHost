---
name: Others
about: 不属于host查询的其它问题
title: "[Issue]"
labels: ''
assignees: ''

---

建议标题以`[Issue]`开头，否则机器人会自动回复hosts
